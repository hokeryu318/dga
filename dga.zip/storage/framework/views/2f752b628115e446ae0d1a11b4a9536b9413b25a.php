<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-6">
                <form action="<?php echo e(route('admin.work.editpost')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                    <input type="hidden" name="work_id" value="<?php echo e($work->id); ?>">
                    <div class="card">
                        <div class="card-header">
                            <strong>Edit Work</strong>
                        </div>
                        <div class="card-body">
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="text-input">Worker Name</label>
                                <div class="col-md-9">
                                    <input type="text" id="text-input" name="name" class="form-control" placeholder="Work name" value="<?php echo e($work->name); ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="select">Worker</label>
                                <div class="col-md-9">
                                <select id="select_worker" name="worker" class="form-control">
                                    <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($worker->id); ?>"
                                            <?php if($work->worker_id == $worker->id): ?>
                                                selected
                                            <?php endif; ?>
                                            ><?php echo e($worker->name); ?></option>                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="select">Equipment</label>
                                <div class="col-md-9">
                                <select id="select_equipment" name="equip" class="form-control">
                                    <?php $__currentLoopData = $equips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($equip->id); ?>"
                                            <?php if($work->equip_id == $equip->id): ?>
                                                selected
                                            <?php endif; ?>
                                            ><?php echo e($equip->name); ?></option>                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="text-input">Work Date</label>
                                <div class="col-md-9">
                                    <input id="work_date" type="text" id="text-input" name="date" class="form-control" value="<?php echo e($work->plan_at); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-dot-circle-o"></i> Submit</button>
                            <button type="reset" class="btn btn-sm btn-danger"><i class="fa fa-ban"></i> Reset</button>
                        </div>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    </div>
                </form>
            </div>
        </div>
        <!--/.row-->
    </div>

</div>
<link rel="stylesheet" href="<?php echo e(asset('plugins/datepicker/datepicker3.css')); ?>"> 
<script src="<?php echo e(asset('plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
<script>
    document.addEventListener("DOMContentLoaded", function(event) { 
        var date = new Date();
        var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        $('#work_date').datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd',
            language: 'en',
            todayHighlight: true
        });
        if($('#work_date').val() == ''){
            $('#work_date').datepicker('setDate', today);
        }
    });  
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('samples', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>