<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-6">
                <form action="<?php echo e(route('admin.area.editpost')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                    <input type="hidden" name="area_id" value="<?php echo e($obj->id); ?>">
                    <div class="card">
                        <div class="card-header">
                            <strong>Edit Area</strong>
                        </div>
                        <div class="card-body">
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="select">Parent Area</label>
                                <div class="col-md-9">
                                    <select id="select" name="parent" class="form-control">
                                    <option value="0">None</option>
                                    <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($parent->id); ?>" 
                                            <?php if($parent->id == $obj->parent_id): ?>
                                            selected
                                            <?php endif; ?>
                                            ><?php echo e($parent->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="text-input">Area Name</label>
                                <div class="col-md-9">
                                    <input type="text" id="text-input" name="areaname" class="form-control" placeholder="Area name" value="<?php echo e($obj->name); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-dot-circle-o"></i> Submit</button>
                            <button type="reset" class="btn btn-sm btn-danger"><i class="fa fa-ban"></i> Reset</button>
                        </div>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    </div>
                </form>
            </div>
        </div>
        <!--/.row-->
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('samples', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>