<!-- Bootstrap and necessary plugins -->
<script src="<?php echo e(asset('js/vendor/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendor/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendor/pace.min.js')); ?>"></script>
<!-- Plugins and scripts required by all views -->
<script src="<?php echo e(asset('js/vendor/Chart.min.js')); ?>"></script>
<!-- CoreUI main scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>