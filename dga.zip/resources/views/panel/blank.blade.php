@extends('master')
@section('content')
<div class="container-fluid">
	<div class="animate fadeIn">
		Blank page
	</div>
</div>
@endsection